from math import pi

radius = float(input('Please, type in the radius:' ))
area = pi*radius**2
print(area)
