# task 2
name = input('Please, type in you name and surname separated by a space: ')
first_name, last_name = name.split()
print (last_name, first_name)