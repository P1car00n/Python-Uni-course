def count_vowels (string):
    vowels = [vowel for vowel in string if vowel in ('a','o','u','e','i')]
    print("Number of vowels: " + str(len(vowels)))
    # print(vowels)

count_vowels('Test string askdjajii9d92dj awdj9')